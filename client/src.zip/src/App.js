import React from "react";
import Main from "./components/Main";

const App = () => {
  return (
    <React.Fragment>
      <Main />
    </React.Fragment>
  );
};

export default App;
