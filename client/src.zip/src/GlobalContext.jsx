import React, { createContext } from "react";

export const GlobalContext = createContext();

const DataProvider = (props) => {
  const data = {};
  return <GlobalContext>{props.children}</GlobalContext>;
};

export default DataProvider;
