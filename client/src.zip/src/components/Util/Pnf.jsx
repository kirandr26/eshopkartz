import React from "react";

const Pnf = () => {
  return <div>Pnf</div>;
};

export default Pnf;
